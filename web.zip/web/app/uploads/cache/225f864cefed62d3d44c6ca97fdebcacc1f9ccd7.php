<footer class="content-info">
  <div class="container">
    <?php (dynamic_sidebar('sidebar-footer')); ?>
      <div class="social">
        <span class="fb">
          <a href=<?php echo $links['facebook']; ?> target="_blank">FB</a>
        </span>
        <span class="tw">
          <a href=""<?php echo $links['twitter']; ?> target="_blank">TW</a>
        </span>
      </div>
      <div class="anio">
        <?php echo $anio; ?><?php echo e(__(' ©', 'sage')); ?>

      </div>
  </div>
</footer>
